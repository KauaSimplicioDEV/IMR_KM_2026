# AULA 03 — Resultados e Relatório Final

**Atividade:** AC-1 — Parte Final  
**Data:** 31/08/2026

> **Observação:** alguns valores numéricos da atividade original chegaram ocultos na mensagem (por exemplo, ângulo/velocidade do Laboratório 2 e alguns limites dos Laboratórios 3–5). Para manter os códigos executáveis, foram usados valores didáticos explícitos nas constantes dos notebooks. Se a folha original da disciplina trouxer valores específicos nesses campos, basta substituir as constantes correspondentes, sem mudar a estrutura dos códigos.

## Laboratório 1 — Raycasting 2D com Pygame

O primeiro laboratório foi usado para entender como o robô consegue perceber obstáculos sem precisar ter um mapa. Foram utilizados três sensores, um para a esquerda, um frontal e um para a direita.

O robô acompanha o mouse e muda sua orientação. A função `cast_rays()` percorre cada raio em pequenos passos e verifica se ele encontrou uma parede da tela ou algum retângulo. Quando encontra um obstáculo, a distância daquele sensor é registrada.

![alt text](image.png)

**Resultado:** o código foi organizado para executar no Pygame e os três raios mudam de comprimento conforme a posição do robô em relação aos obstáculos. Quando há colisão com um obstáculo, o raio fica indicado como colisão.

## Laboratório 2 — Rotação In-Place

Neste exercício, o objetivo foi validar a cinemática angular fazendo o robô girar sobre o próprio eixo, sem alterar sua posição no espaço.

Foi definido um ângulo de giro de 90 graus e uma velocidade angular de 0,5 rad/s. A partir desses valores, o tempo necessário para realizar a rotação foi calculado pela relação entre o ângulo desejado e a velocidade angular.

Durante a execução, o robô altera apenas sua orientação (theta), mantendo sua posição fixa. A rotação é realizada no sentido anti-horário. Ao atingir o tempo calculado, a velocidade angular é zerada e o giro é finalizado.

Resultado: o robô conseguiu realizar a rotação sobre o próprio eixo, mudando sua orientação sem se deslocar pela tela. O exercício ajudou a entender melhor a relação entre ângulo, velocidade angular e tempo de movimento.

![alt text](image-4.png)

## Laboratório 3 — Percepção com Múltiplos Sensores

Neste laboratório o sistema passou de três para cinco sensores de feixe. Cada sensor verifica as paredes externas e os obstáculos retangulares.

Também foi incluído ruído gaussiano usando `np.random.normal(0, 2.0)`, como solicitado. Isso deixa a simulação um pouco mais próxima de uma leitura real, porque o sensor não retorna exatamente o mesmo valor ideal todas as vezes.

**Resultado:** os cinco raios são desenhados em tempo real e cada um apresenta sua distância aproximada na tela. O ruído faz com que as leituras tenham pequenas variações.
![alt text](image-1.png)

## Laboratório 4 — Veículo de Braitenberg: Medo Puro

Este foi o exercício em que o comportamento reativo ficou mais evidente. O robô não recebe um alvo. Ele simplesmente reage ao que os sensores estão percebendo.

Foi utilizada a ideia cruzada de Braitenberg: o sensor da direita influencia a roda esquerda e o sensor da esquerda influencia a roda direita. Dessa forma, quando um obstáculo fica mais próximo de um lado, o robô aumenta a resposta da roda oposta para se afastar da ameaça.

Quando o sensor central detecta um obstáculo muito próximo, uma das rodas é invertida para produzir um giro rápido sobre o próprio eixo.

**Resultado:** o robô percorre a sala e reage aos obstáculos sem utilizar mapa ou destino. A principal característica observada é que o movimento surge diretamente da relação entre sensação e ação.

![alt text](image-2.png)

## Laboratório 5 — Go-to-Goal com Desvio Reativo

No último laboratório foi acrescentado um objetivo. O usuário pode clicar em um ponto da tela e o robô tenta chegar até ele.

O comportamento possui dois modos. No primeiro, o controlador proporcional direciona o robô para o alvo. No segundo, quando algum sensor identifica uma distância de emergência, o controle de desvio passa a dominar a velocidade angular, fazendo o robô se afastar do obstáculo.

Ao chegar suficientemente perto do alvo, o robô para.

**Resultado:** o robô tenta perseguir o ponto escolhido e, quando encontra uma região bloqueada, reduz a velocidade e realiza uma correção de direção. Depois que a região fica livre, volta a seguir o alvo.

![alt text](image-3.png)



# Exercício de maior dificuldade

O exercício que achei mais difícil foi o **Laboratório 4 — Veículo de Braitenberg**.

A dificuldade principal foi entender como transformar diretamente uma distância medida pelo sensor em velocidade das rodas. No começo é fácil pensar que o robô deveria simplesmente mandar virar para o lado contrário do obstáculo, mas na prática a velocidade de cada roda precisa ser calculada de forma coerente para produzir esse comportamento.

Também achei um pouco difícil entender a ideia de cruzar os sensores com as rodas. Quando o obstáculo aparece do lado direito, por exemplo, o sensor direito influencia a roda esquerda. Depois de observar o resultado na simulação, ficou mais fácil entender que essa diferença de velocidades gera a curva necessária para o robô se afastar.

# Impressões gerais sobre os algoritmos de Robôs Inteligentes Móveis

Minha principal impressão até agora é que um robô inteligente não precisa necessariamente ter um mapa completo do ambiente para tomar decisões simples. Ele pode perceber o que está acontecendo naquele momento pelos sensores e reagir imediatamente.

A parte mais difícil para mim é conectar as três etapas: **sensor → decisão → movimento**. É relativamente fácil calcular uma distância ou uma velocidade separadamente, mas entender como essas informações viram um comportamento do robô exige mais atenção.

Também percebi que pequenos detalhes matemáticos fazem bastante diferença no movimento. A diferença entre as velocidades das rodas altera a orientação do robô, enquanto a velocidade média influencia o deslocamento. No caso dos sensores, pequenas mudanças na distância podem modificar bastante a reação quando existe um ganho proporcional.

De forma geral, os exercícios ajudaram a deixar mais claro como conceitos de programação, matemática e cinemática se juntam para produzir um comportamento de robô. A parte que mais chamou minha atenção foi justamente a possibilidade de conseguir comportamentos relativamente complexos usando regras reativas simples, sem precisar criar previamente um mapa do ambiente.
